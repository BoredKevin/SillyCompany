# SillyCompany
This silly modpack offers many funny & useful changes to the game that includes changes to the game audio,
the mechanics of the monsters in the game, and much more! Dive in to experience some funny moments when playing
with your friends using this modpack!

## ISSUES

If you encounter any issues while playing with the modpack, you may report those issues [here](https://github.com/BoredKevin/SillyCompany/issues)

**Please make sure you have the full detailed console log before making a new issue, otherwise we will NOT help you!**

## CHANGELOG

### v0.0.1

Initial commit