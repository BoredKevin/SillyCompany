# SillyCompany
This silly modpack offers many funny & useful changes to the game that includes changes to the game audio,
the mechanics of the monsters in the game, and much more! Dive in to experience some funny moments when playing
with your friends using this modpack!

## CHANGELOG

### v0.0.1

Initial commit

